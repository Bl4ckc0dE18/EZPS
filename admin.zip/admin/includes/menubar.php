<?php $posistion = $user['position']; ?>


<aside class="main-sidebar"  style="height:100%">
    <!-- sidebar: style can be found in sidebar.less -->
    <section class="sidebar">
      <!-- Sidebar user panel -->
      <div class="user-panel">
        <div class="pull-left image">
          <img src="<?php echo (!empty($user['photo'])) ? '../images/'.$user['photo'] : '../images/profile.jpg'; ?>" class="img-circle" alt="User Image">
        </div>
        <div class="pull-left info">
          <p><?php echo $user['firstname'].' '.$user['lastname']; ?></p>
          <a><i class="fa fa-circle text-success"></i> Online</a>
        </div>
      </div>
      <!-- sidebar menu: : style can be found in sidebar.less -->
      <ul class="sidebar-menu" data-widget="tree">
        <li class="header"></li>
        <li class=""><a href="home.php"><i class="fa fa-home"></i> <span>Home</span></a></li>
        <li class="header">MANAGE</li>         
              <li><a href="attendance.php"><i class="fa fa-th-list"></i> <span>Attendance</span></a></li>       
        <li class="treeview">
          <a href="#">
            <i class="fa fa-users"></i>
            <span>Employee</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
          <?php if($posistion == 'Admin' ||$posistion == 'Human Resources' ){?>
            <li><a href="employee.php"><i class="fa fa-circle-o"></i> Employee List</a></li>    
            <li><a href="schedule.php"><i class="fa fa-circle-o"></i> Schedules</a></li>
            <li><a href="leave.php"><i class="fa fa-circle-o"></i> Manage Employees Leave</a></li>
            <?php }?>

            <?php if($posistion == 'Admin' ||$posistion == 'Accountant' ){?>
            <li><a href="bonus.php"><i class="fa fa-circle-o"></i> Bonus</a></li>
            <?php }?>
          </ul>
        </li>
        <!--  -->

        <?php 
            if($posistion == 'Admin' ||$posistion == 'Accountant' ){
              ?>
        <li class="treeview">
          <a href="#">
            <i class="fa fa-file-o"></i>
            <span>Deductions</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">

            <li><a href="benefits.php"><i class="fa fa-circle-o"></i> Benefit Records</a></li>
            <li><a href="sss.php"><i class="fa fa-circle-o"></i> SSS</a></li>
            <li><a href="pagibig.php"><i class="fa fa-circle-o"></i> PAG-IBIG</a></li>
            <li><a href="philhealth.php"><i class="fa fa-circle-o"></i> PHILHEALTH</a></li> 
            <li><a href="cashadvance.php"><i class="fa fa-circle-o"></i> Cash Advance</a></li>

          </ul>
        </li>

        <?php }?>
        <!--  -->
        
        <!--  -->
        
        <?php if($posistion == 'Admin' ||$posistion == 'Human Resources' ){?>
        <li><a href="position.php"><i class="fa fa-building"></i> <span>Positions</span></a></li>
        <?php } if($posistion == 'Admin' ){?>
        <li><a href="user.php"><i class="fa fa-user"></i> <span>User</span></a></li>
        <?php }?>
        <li class="header">PRINTABLES</li>
        <?php if($posistion == 'Admin' ||$posistion == 'Accountant' ){?>
        <li><a href="payroll.php"><i class="fa fa-columns"></i> <span>Payroll</span></a></li>
        <?php } if($posistion == 'Admin' ||$posistion == 'Human Resources' ){?>
        <li><a href="schedule_employee.php"><i class="fa fa-clock-o"></i> <span>Schedule</span></a></li>
        <?php }?>
        <!-- <li> </li>
        <li> </li>
        <li> </li>
        <li> </li>
        <li> </li>
        <li> </li>
        <li> </li>
        <li> </li>
        <li> </li>
        <li> </li>
        <li> </li>
        <li> </li>
        <li> </li>
        <li> </li>
        <li> </li>
        <li> </li>
        <li> </li>
        <li> </li>
        <li> </li>
        <li> </li>
        <li> </li>        
        <li> </li>
        <li> </li> -->

      </ul>
    </section>
    <!-- /.sidebar -->
  </aside>