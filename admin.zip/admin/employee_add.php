<?php
	include 'includes/session.php';

	if(isset($_POST['add'])){
		$employee_id = $_POST['employee_id'];
		$employee_rfid = $_POST['employee_rfid'];
		$firstname = $_POST['firstname'];
		$lastname = $_POST['lastname'];
		$address = $_POST['address'];
		$birthdate = $_POST['birthdate'];
		$contact = $_POST['contact'];
		$gender = $_POST['gender'];
		$email = $_POST['email'];
		$password = password_hash($_POST['password'], PASSWORD_DEFAULT);
		$position = $_POST['position'];
		$schedule = $_POST['schedule'];
		$filename = $_FILES['photo']['name'];
		$date_contract_end = $_POST['datepicker_employee_add'];
		if(!empty($filename)){
			move_uploaded_file($_FILES['photo']['tmp_name'], '../images/'.$filename);	
		}
		//creating employeeid
		$set = '1234567890';
		$date_contract = date('Y-m-d');
		$employee_id = ((date('Y')).substr(str_shuffle($set), 0, 15));
		
		$sql = "INSERT INTO employees (employee_id, employee_rfid,firstname, lastname, address, birthdate, contact_info, gender,email ,password,position_id, schedule_id, photo, created_on,end_contract) 
		VALUES ('$employee_id','$employee_rfid', '$firstname', '$lastname', '$address', '$birthdate', '$contact', '$gender','$email','$password', '$position', '$schedule', '$filename', '$date_contract','$date_contract_end')";
		if($conn->query($sql)){
			$_SESSION['success'] = 'Employee added successfully';
		}
		else{
			$_SESSION['error'] = $conn->error;
		}

	}
	else{
		$_SESSION['error'] = 'Fill up add form first';
	}

	header('location: employee.php');
?>