<?php
	include 'includes/session.php';

	if(isset($_POST['edit'])){
		$empid = $_POST['id'];
		$employee_id = $_POST['employee_id'];
		$employee_rfid = $_POST['employee_rfid'];
		$firstname = $_POST['firstname'];
		$lastname = $_POST['lastname'];
		$address = $_POST['address'];
		$birthdate = $_POST['birthdate'];
		$contact = $_POST['contact'];
		$gender = $_POST['gender'];
		$email = $_POST['email'];
		$password = $_POST['password'];
		$position = $_POST['position'];
		$schedule = $_POST['schedule'];
		$date_contract_end = $_POST['datepicker_employee_edit'];
		
		$sql = "UPDATE employees SET employee_id = '$employee_id',employee_rfid = '$employee_rfid', firstname = '$firstname', lastname = '$lastname', address = '$address', birthdate = '$birthdate', contact_info = '$contact', gender = '$gender', email = '$email', password = '$password', position_id = '$position', schedule_id = '$schedule', end_contract = '$date_contract_end' WHERE id = '$empid'";
		if($conn->query($sql)){
			$_SESSION['success'] = 'Employee updated successfully';
		}
		else{
			$_SESSION['error'] = $conn->error;
		}

	}
	else{
		$_SESSION['error'] = 'Select employee to edit first';
	}

	header('location: employee.php');
?>